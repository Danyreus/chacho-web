# SCRIPT DE OPTIMIZACIÓN CHACHOS V2.0 (NIVEL AVANZADO - GAMING)
# Incluye V1.0 + Desactivación de Servicios y Optimizaciones de Red
# ¡Ejecutar como ADMINISTRADOR!

# ----------------------------------------------------------------
# PASO 1: Desactivar la Política de Ejecución de Scripts
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

# ----------------------------------------------------------------
# PASO 2: Eliminar Bloatware (Aplicaciones de la Tienda de Microsoft)
Write-Host "Iniciando eliminación de Bloatware..." -ForegroundColor Green
# (Mismo código de Bloatware que en V1.0)
$AppsToRemove = @(
    "*3DBuilder*",        
    "*BingNews*",         
    "*Microsoft.ZuneVideo*", 
    "*Microsoft.Xbox*",   
    "*Microsoft.GetHelp*", 
    "*Microsoft.Office.OneNote*", 
    "*Microsoft.People*", 
    "*Microsoft.SkypeApp*", 
    "*Microsoft.WindowsMaps*", 
    "*windowscommunicationsapps*", 
    "*CandyCrushSodaSaga*", 
    "*PowerShellISE*" 
)

foreach ($App in $AppsToRemove) {
    Get-AppxPackage $App | Remove-AppxPackage -ErrorAction SilentlyContinue
    Get-AppxProvisionedPackage -Online | Where-Object { $_.PackageName -like $App } | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue
}
Write-Host "Bloatware eliminado o deshabilitado con éxito." -ForegroundColor Green

# ----------------------------------------------------------------
# PASO 3: Desactivar Telemetría y Recolección de Datos
Write-Host "Desactivando servicios de Telemetría..." -ForegroundColor Green
# (Mismo código de Telemetría que en V1.0)
Set-Service -Name DiagTrack -StartupType Disabled -Confirm:$false
Stop-Service -Name DiagTrack -Force -ErrorAction SilentlyContinue
Set-Service -Name dps -StartupType Disabled -Confirm:$false
Stop-Service -Name dps -Force -ErrorAction SilentlyContinue

$TasksToDisable = @(
    "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
    "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"
)

foreach ($TaskPath in $TasksToDisable) {
    try {
        $Task = Get-ScheduledTask -TaskPath $TaskPath -ErrorAction Stop
        if ($Task) {
            Disable-ScheduledTask -InputObject $Task -ErrorAction Stop | Out-Null
            Write-Host "Tarea desactivada: $TaskPath" -ForegroundColor Cyan
        }
    }
    catch {
        Write-Host "Tarea omitida (no existe en este sistema): $TaskPath" -ForegroundColor Yellow
    }
}

# ----------------------------------------------------------------
# PASO 4: Optimización del Registro (Prioridad y Tema Oscuro)
Write-Host "Aplicando ajustes de rendimiento y Tema Oscuro en el Registro..." -ForegroundColor Green
# (Mismo código de Registro que en V1.0)
$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
Set-ItemProperty -Path $RegPath -Name SystemResponsiveness -Value 10 -Type DWord -ErrorAction SilentlyContinue
$RegPath2 = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace"
Set-ItemProperty -Path $RegPath2 -Name "00000000-0000-0000-0000-000000000000" -Value "" -Type String -ErrorAction SilentlyContinue
$ThemePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
Set-ItemProperty -Path $ThemePath -Name AppsUseLightTheme -Value 0 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty -Path $ThemePath -Name SystemUseLightTheme -Value 0 -Type DWord -ErrorAction SilentlyContinue

# ----------------------------------------------------------------
# PASO 5: Aplicar Fondo de Pantalla Personalizado
Write-Host "Buscando y aplicando fondo de pantalla personalizado..." -ForegroundColor Green
# (Mismo código de Fondo que en V1.0)
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$RootDir = Split-Path -Parent $ScriptDir
$WallpaperFile = Get-ChildItem -Path $RootDir -Filter "ChachOS_Fondo.*" -ErrorAction SilentlyContinue | Select-Object -First 1

if ($null -ne $WallpaperFile) {
    $ImagePath = $WallpaperFile.FullName
    Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name Wallpaper -Value $ImagePath -Type String -ErrorAction SilentlyContinue
    Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name WallpaperStyle -Value 2 -Type String -ErrorAction SilentlyContinue
    Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name TileWallpaper -Value 0 -Type String -ErrorAction SilentlyContinue
    rundll32.exe user32.dll,UpdatePerUserSystemParameters 1, True
    Write-Host "Fondo de pantalla encontrado y aplicado: $($WallpaperFile.Name)." -ForegroundColor Green
} else {
    Write-Host "ADVERTENCIA: No se encontró la imagen 'ChachOS_Fondo.*' en el directorio principal. El fondo no se pudo cambiar." -ForegroundColor Red
}

# ----------------------------------------------------------------
# PASO 6: Servicios Adicionales (Gaming)
Write-Host "Desactivando servicios avanzados no esenciales para Gaming..." -ForegroundColor Yellow

$ServicesToDisable = @("Spooler", "Fax", "SysMain", "WSearch")

foreach ($Service in $ServicesToDisable) {
    try {
        # Deshabilita el inicio y lo detiene
        Set-Service -Name $Service -StartupType Disabled -Confirm:$false -ErrorAction Stop
        Stop-Service -Name $Service -Force -ErrorAction Stop
        Write-Host "Servicio desactivado: $Service" -ForegroundColor Cyan
    }
    catch {
        Write-Host "Advertencia: El servicio $Service no pudo ser detenido o ya estaba desactivado." -ForegroundColor Yellow
    }
}

# ----------------------------------------------------------------
# PASO 7: Optimización de Red (Latencia)
Write-Host "Aplicando ajustes de Red para reducir latencia (Gaming)..." -ForegroundColor Yellow

# Deshabilitar el Algoritmo de Nagle (Aceleración de conexión para Gaming)
$NaglePath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
$Interfaces = Get-ChildItem $NaglePath

foreach ($Interface in $Interfaces) {
    $InterfacePath = $Interface.PSPath
    # TcpNoDelay (Deshabilitar Nagle)
    Set-ItemProperty -Path $InterfacePath -Name TcpNoDelay -Value 1 -Type DWord -ErrorAction SilentlyContinue
    # TcpAckFrequency (Reducir el retraso de confirmación)
    Set-ItemProperty -Path $InterfacePath -Name TcpAckFrequency -Value 1 -Type DWord -ErrorAction SilentlyContinue
}

Write-Host "Optimización de Red aplicada." -ForegroundColor Cyan
# ----------------------------------------------------------------

Write-Host "`n✅ Optimización ChachOS V2.0 (Avanzado) Completa." -ForegroundColor Green
Write-Host "🚨 El sistema debe Reiniciarse para aplicar todos los cambios." -ForegroundColor Red