# SCRIPT DE OPTIMIZACIÓN CHACHOS V1.0 (NIVEL EQUILIBRADO)
# Objetivo: Eliminar Bloatware de Windows, Desactivar Telemetría, Optimizar Registro y Cambiar Fondo.
# ¡Ejecutar como ADMINISTRADOR!

# ----------------------------------------------------------------
# PASO 1: Desactivar la Política de Ejecución de Scripts
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force

# ----------------------------------------------------------------
# PASO 2: Eliminar Bloatware (Aplicaciones de la Tienda de Microsoft)
Write-Host "Iniciando eliminación de Bloatware..." -ForegroundColor Green

$AppsToRemove = @(
    "*3DBuilder*",        
    "*BingNews*",         
    "*Microsoft.ZuneVideo*", 
    "*Microsoft.Xbox*",   
    "*Microsoft.GetHelp*", 
    "*Microsoft.Office.OneNote*", 
    "*Microsoft.People*", 
    "*Microsoft.SkypeApp*", 
    "*Microsoft.WindowsMaps*", 
    "*windowscommunicationsapps*", 
    "*CandyCrushSodaSaga*", 
    "*PowerShellISE*" 
)

foreach ($App in $AppsToRemove) {
    Get-AppxPackage $App | Remove-AppxPackage -ErrorAction SilentlyContinue
    Get-AppxProvisionedPackage -Online | Where-Object { $_.PackageName -like $App } | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue
}
Write-Host "Bloatware eliminado o deshabilitado con éxito." -ForegroundColor Green

# ----------------------------------------------------------------
# PASO 3: Desactivar Telemetría y Recolección de Datos
Write-Host "Desactivando servicios de Telemetría..." -ForegroundColor Green

# 3.1 Desactivar el Servicio de Experiencias de Usuario y Telemetría
Set-Service -Name DiagTrack -StartupType Disabled -Confirm:$false
Stop-Service -Name DiagTrack -Force -ErrorAction SilentlyContinue

# 3.2 Desactivar el Servicio de Diagnóstico
Set-Service -Name dps -StartupType Disabled -Confirm:$false
Stop-Service -Name dps -Force -ErrorAction SilentlyContinue

# 3.3 Desactivar Tareas Programadas de Monitoreo (CORREGIDO)
$TasksToDisable = @(
    "\Microsoft\Windows\Customer Experience Improvement Program\Consolidator",
    "\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"
)

foreach ($Task in $TasksToDisable) {
    # Usamos un try/catch para ignorar errores si la tarea no existe o falla al desactivarse.
    try {
        Disable-ScheduledTask -TaskPath $Task -ErrorAction Stop
        Write-Host "Tarea desactivada: $Task" -ForegroundColor Cyan
    }
    catch {
        Write-Host "Advertencia: La tarea $Task no existe o falló al desactivarse." -ForegroundColor Yellow
    }
}

# ----------------------------------------------------------------
# PASO 4: Optimización del Registro (Ajuste de Prioridad)
Write-Host "Aplicando ajustes de rendimiento en el Registro..." -ForegroundColor Green

# Prioridad de la aplicación en primer plano.
$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
Set-ItemProperty -Path $RegPath -Name SystemResponsiveness -Value 10 -Type DWord -ErrorAction SilentlyContinue

# Desactiva la función de "Throttling" del Administrador de energía
$RegPath2 = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\ControlPanel\NameSpace"
Set-ItemProperty -Path $RegPath2 -Name "00000000-0000-0000-0000-000000000000" -Value "" -Type String -ErrorAction SilentlyContinue

# ----------------------------------------------------------------
# PASO 5: Aplicar Fondo de Pantalla Personalizado
Write-Host "Aplicando fondo de pantalla personalizado..." -ForegroundColor Green

# Obtener la ruta de la carpeta principal (la que contiene el .bat y la imagen)
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$RootDir = Split-Path -Parent $ScriptDir
$WallpaperFile = "ChachOS_Fondo.jpg" 
$ImagePath = Join-Path $RootDir $WallpaperFile

# Establecer la ruta del fondo en el Registro
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name Wallpaper -Value $ImagePath -Type String -ErrorAction SilentlyContinue

# Establecer estilo de ajuste (2 = Ajustar, 0 = Centro, etc.)
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name WallpaperStyle -Value 2 -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name TileWallpaper -Value 0 -Type String -ErrorAction SilentlyContinue

# Aplicar los cambios inmediatamente (hace que el fondo cambie sin reiniciar)
rundll32.exe user32.dll,UpdatePerUserSystemParameters 1, True

Write-Host "Fondo de pantalla ChachOS_Fondo aplicado." -ForegroundColor Green
# ----------------------------------------------------------------

Write-Host "`n✅ Optimización ChachOS V1.0 Completa." -ForegroundColor Green
Write-Host "🚨 El sistema debe Reiniciarse para aplicar el resto de los cambios." -ForegroundColor Red