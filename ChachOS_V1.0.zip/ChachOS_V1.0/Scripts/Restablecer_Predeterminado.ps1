# SCRIPT DE RESTAURACIÓN CHACHOS (VUELTA A VALORES PREDETERMINADOS)
# Objetivo: Revertir los cambios principales de optimización de ChachOS a los valores de Windows.
# ¡Ejecutar como ADMINISTRADOR!

# ----------------------------------------------------------------
# PASO 1: Reestablecer Servicios de Windows
Write-Host "Restableciendo servicios de Telemetría y adicionales..." -ForegroundColor Yellow

# Restaurar Servicios de Telemetría (a su valor predeterminado 'Manual' o 'Automático')
Set-Service -Name DiagTrack -StartupType Manual -Confirm:$false -ErrorAction SilentlyContinue
Start-Service -Name DiagTrack -ErrorAction SilentlyContinue
Set-Service -Name dps -StartupType Automatic -Confirm:$false -ErrorAction SilentlyContinue
Start-Service -Name dps -ErrorAction SilentlyContinue

# Restaurar Servicios de Gaming/Avanzados (a su valor predeterminado)
Set-Service -Name Spooler -StartupType Automatic -Confirm:$false -ErrorAction SilentlyContinue # Impresión
Start-Service -Name Spooler -ErrorAction SilentlyContinue
Set-Service -Name Fax -StartupType Manual -Confirm:$false -ErrorAction SilentlyContinue # Fax
Set-Service -Name SysMain -StartupType Automatic -Confirm:$false -ErrorAction SilentlyContinue # Superfetch/SysMain
Set-Service -Name WSearch -StartupType Automatic -Confirm:$false -ErrorAction SilentlyContinue # Windows Search
Start-Service -Name WSearch -ErrorAction SilentlyContinue

Write-Host "Servicios principales restaurados." -ForegroundColor Yellow

# ----------------------------------------------------------------
# PASO 2: Restaurar Tema a Modo Claro (Light Mode)
Write-Host "Restaurando tema a Modo Claro (Light Mode)..." -ForegroundColor Yellow

$ThemePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
# 1 = Modo Claro (Light Mode)
Set-ItemProperty -Path $ThemePath -Name AppsUseLightTheme -Value 1 -Type DWord -ErrorAction SilentlyContinue
Set-ItemProperty -Path $ThemePath -Name SystemUseLightTheme -Value 1 -Type DWord -ErrorAction SilentlyContinue

# ----------------------------------------------------------------
# PASO 3: Restaurar Optimización de Registro y Prioridad
Write-Host "Restaurando ajustes de Prioridad de CPU y Red..." -ForegroundColor Yellow

# Restaurar Prioridad de aplicación en primer plano (Valor predeterminado: 20)
$RegPath = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
Set-ItemProperty -Path $RegPath -Name SystemResponsiveness -Value 20 -Type DWord -ErrorAction SilentlyContinue

# Eliminar claves de Nagle/Latencia (Latencia)
$NaglePath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
$Interfaces = Get-ChildItem $NaglePath

foreach ($Interface in $Interfaces) {
    $InterfacePath = $Interface.PSPath
    Remove-ItemProperty -Path $InterfacePath -Name TcpNoDelay -ErrorAction SilentlyContinue
    Remove-ItemProperty -Path $InterfacePath -Name TcpAckFrequency -ErrorAction SilentlyContinue
}

# ----------------------------------------------------------------
# PASO 4: Restaurar Fondo de Pantalla a Predeterminado
Write-Host "Limpiando Fondo de Pantalla personalizado..." -ForegroundColor Yellow

# Limpiar las claves personalizadas del fondo de pantalla para forzar a Windows a usar su configuración predeterminada
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name Wallpaper -Value "" -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name WallpaperStyle -Value 0 -Type String -ErrorAction SilentlyContinue
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop" -Name TileWallpaper -Value 0 -Type String -ErrorAction SilentlyContinue

# Forzar la actualización inmediata (cambia el tema y el fondo)
rundll32.exe user32.dll,UpdatePerUserSystemParameters 1, True

# ----------------------------------------------------------------

Write-Host "`n✅ Restauración de ChachOS Playbook completa." -ForegroundColor Green
Write-Host "🚨 El sistema debe Reiniciarse para aplicar todos los cambios." -ForegroundColor Red