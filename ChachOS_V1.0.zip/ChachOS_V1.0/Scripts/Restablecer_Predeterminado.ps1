# ----------------------------------------------------------------
# SCRIPT DE RESTABLECIMIENTO DE CHACHOS (Versión Futura)
# ----------------------------------------------------------------
# En esta version, la funcion de restablecimiento no esta activa.
# El objetivo de este script sera revertir los cambios de registro y 
# reactivar los servicios deshabilitados por ChachOS.
# ----------------------------------------------------------------
Write-Host "Restablecimiento no disponible en ChachOS V1.0. Estara disponible en la proxima version."